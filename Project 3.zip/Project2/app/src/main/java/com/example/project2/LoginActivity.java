package com.example.project2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

   @Override
   protected void onCreate(Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
      setContentView(R.layout.activity_login);

      //Link UI elements to code
      usernameField = findViewById(R.id.username);
      passwordField = findViewById(R.id.password);
      Button loginButton = findViewById(R.id.btn_login);
      Button registerButton = findViewById(R.id.btn_register);

      //login button logic
      loginButton.setOnClickListener(v -> {
                 String username = usernameField.getText().toString();
                 String password = passwordField.getText().toString();

                 //Example: simple login logic
                 if (username.equals("admin") && password.equals("1234")) {
                    Toast.makeText(LoginActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                    //Navigate to next screen
                    Intent intent = new Intent(LoginActivity.this, GridActivity.class);
                    startActivity(intent);
                 } else {
                    Toast.makeText(LoginActivity.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
                 }
              });
      //create account button logic
      registerButton.setOnClickListener(v -> {
         //navigate to account creation screen
         Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
         startActivity(intent);
      });
   }
    
}
